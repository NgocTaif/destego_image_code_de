import sys

def binary_to_ascii(binary_str):
    try:
        if len(binary_str) % 8 != 0:
            raise ValueError("Binary string length is not valid.")
        
        ascii_text = ""
        for i in range(0, len(binary_str), 8):
            byte = binary_str[i:i+8] 
            decimal = int(byte, 2)   
            char = chr(decimal)    
            ascii_text += char
        
        print(f"ASCII string: {ascii_text}")
        
    except Exception as e:
        print(f"Error: {e}")

binary_str = sys.argv[1]
binary_to_ascii(binary_str)
