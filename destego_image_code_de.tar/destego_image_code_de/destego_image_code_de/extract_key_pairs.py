import sys

def read_matrix(file_path):
    matrix = []
    with open(file_path, 'r') as file:
        for line in file:
            row = list(map(int, line.strip().split()))
            matrix.append(row)
    return matrix

def extract_pairs(matrix_file, row_idx, start_col, end_col, output_file):
    try:
        matrix = read_matrix(matrix_file)
        
        if row_idx < 0 or row_idx >= len(matrix):
            raise ValueError(f"Row index is not valid.")
        if start_col < 0 or end_col >= len(matrix[0]) or start_col > end_col:
            raise ValueError(f"Column index is not valid.")
        
        pairs = []
        col = start_col
        while col < end_col:
            if col + 1 <= end_col: 
                pair = (matrix[row_idx][col], matrix[row_idx][col + 1])
                pairs.append(pair)
                col += 2 
            else:
                break
        
        with open(output_file, 'w') as outfile:
            for x, y in pairs:
                outfile.write(f"{x} {y}\n")
        
        print(f"Extracted key pairs: {output_file}")
        
    except FileNotFoundError:
        print(f"Not found: {matrix_file}")
    except Exception as e:
        print(f"Error: {e}")

matrix_file = sys.argv[1]
row_idx = int(sys.argv[2])
start_col = int(sys.argv[3])
end_col = int(sys.argv[4])
output_file = "key_pairs.txt"
extract_pairs(matrix_file, row_idx, start_col, end_col, output_file)